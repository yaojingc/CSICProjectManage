/**
* @description: 表体编辑后事件
* @param: moduleId 区域编码
* @param: key 当前字段编码
*/
export function afterTableEvent(props, moduleId, key, value, changedrows, index, record, type, method) {
        
}
