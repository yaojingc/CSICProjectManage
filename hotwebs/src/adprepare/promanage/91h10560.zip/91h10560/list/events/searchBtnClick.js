import { listSearch } from './listOperator';

//点击查询，获取查询区数据
export function searchBtnClick(props) {
        listSearch(props);
}
