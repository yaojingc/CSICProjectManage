/**
* @description: 表体编辑前事件
* @param: moduleId 区域编码
* @param: key 当前字段编码
* @return: 布尔 true表示可编辑
*/
export function beforeTableEvent(props, moduleId, key, value, index, record, status) {
        return true;
}
